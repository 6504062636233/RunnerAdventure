RunnerAdventure_v5 - Java 2D Endless Runner (Prototype)
-------------------------------------------------------
This version (v5) includes:
- Coins (+10 score each)
- Items: HEART (heal), BIG (become big and destroy obstacles), SPEED (speed boost)
- Obstacles sometimes move vertically (wave motion)
- Items spawn at least 150px away from obstacles
- Player has 3 lives (can hit obstacles 3 times before game over)
How to run:
1. Open project in an IDE (IntelliJ/Eclipse/VS Code with Java)
2. Ensure 'assets' folder is next to .java files
3. Run Main.java
Controls:
- ENTER: Start / Restart
- SPACE: Jump
- S: Slide (placeholder)
